package or;

import org.openqa.selenium.By;

public class UserPageElements {
	
	public static By verifyUser=By.xpath("//*[@id='feed-posting-text']/p[1]");

}
