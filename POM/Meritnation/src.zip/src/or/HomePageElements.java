package or;

import org.openqa.selenium.By;

public class HomePageElements {
	
	public static By loginLink=By.xpath("//span[@class='hidden-xs']");
	public static By frame=By.id("container-notification-frame-5882433d70d710263cc79b04");
	
	public static By close=By.xpath("//div[@id='co-close-icon-5882433d70d710263cc79b04']");

	/*public static By getLoginLink() {
		return By.xpath("");
	}
*/
}
